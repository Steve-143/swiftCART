import { ShoppingCart, Search, User, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Link, useLocation } from "react-router-dom";
import { useState } from "react";

interface HeaderProps {
  cartItemsCount?: number;
}

export const Header = ({ cartItemsCount = 0 }: HeaderProps) => {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isAdminRoute = location.pathname.startsWith('/admin');

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 animate-fade-in">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2 hover-scale transition-swift">
          <div className="gradient-primary h-8 w-8 rounded-lg flex items-center justify-center">
            <ShoppingCart className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Swift Cart
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/" className="story-link text-sm font-medium transition-colors hover:text-primary">
            Home
          </Link>
          <Link to="/products" className="story-link text-sm font-medium transition-colors hover:text-primary">
            Products
          </Link>
          <Link to="/about" className="story-link text-sm font-medium transition-colors hover:text-primary">
            About
          </Link>
          <Link to="/contact" className="story-link text-sm font-medium transition-colors hover:text-primary">
            Contact
          </Link>
        </nav>

        {/* Search Bar (Desktop) */}
        <div className="hidden md:flex items-center space-x-2 flex-1 max-w-sm mx-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search products..."
              className="pl-9 bg-muted/50"
            />
          </div>
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center space-x-2">
          {!isAdminRoute && (
            <Link to="/admin">
              <Button variant="ghost" size="sm" className="hover-scale transition-swift">
                Admin
              </Button>
            </Link>
          )}
          
          {isAdminRoute && (
            <Link to="/">
              <Button variant="ghost" size="sm" className="hover-scale transition-swift">
                Store
              </Button>
            </Link>
          )}

          <Button variant="ghost" size="icon" className="hover-scale transition-swift">
            <User className="h-5 w-5" />
          </Button>

          {!isAdminRoute && (
            <Link to="/cart">
              <Button variant="ghost" size="icon" className="relative hover-scale transition-swift">
                <ShoppingCart className="h-5 w-5" />
                {cartItemsCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs animate-scale-in"
                  >
                    {cartItemsCount}
                  </Badge>
                )}
              </Button>
            </Link>
          )}

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden hover-scale transition-swift"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t bg-background animate-slide-in-right">
          <div className="container py-4 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                className="pl-9 bg-muted/50"
              />
            </div>
            <nav className="space-y-2">
              <Link 
                to="/" 
                className="story-link block py-2 text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/products" 
                className="story-link block py-2 text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Products
              </Link>
              <Link 
                to="/about" 
                className="story-link block py-2 text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link 
                to="/contact" 
                className="story-link block py-2 text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};