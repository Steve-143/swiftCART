import { Button } from "@/components/ui/button";
import { ProductCard, Product } from "@/components/ProductCard";
import { Header } from "@/components/Header";
import { ArrowRight, Truck, Shield, Zap, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import heroImage from "@/assets/hero-shopping.jpg";

// Mock data for featured products
const featuredProducts: Product[] = [
  {
    id: "1",
    name: "Premium Wireless Headphones",
    price: 199.99,
    originalPrice: 299.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop&crop=center",
    rating: 4.8,
    reviewCount: 234,
    category: "Electronics",
    isOnSale: true,
    isFeatured: true,
  },
  {
    id: "2",
    name: "Organic Cotton T-Shirt",
    price: 29.99,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop&crop=center",
    rating: 4.5,
    reviewCount: 89,
    category: "Clothing",
    isFeatured: true,
  },
  {
    id: "3",
    name: "Stainless Steel Water Bottle",
    price: 24.99,
    originalPrice: 34.99,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop&crop=center",
    rating: 4.9,
    reviewCount: 156,
    category: "Home & Garden",
    isOnSale: true,
  },
  {
    id: "4",
    name: "Smart Fitness Watch",
    price: 149.99,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop&crop=center",
    rating: 4.6,
    reviewCount: 312,
    category: "Electronics",
    isFeatured: true,
  },
];

export default function Homepage() {
  const [cartItems, setCartItems] = useState<Product[]>([]);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const handleAddToCart = (product: Product) => {
    setCartItems(prev => [...prev, product]);
  };

  const handleToggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(productId)) {
        newFavorites.delete(productId);
      } else {
        newFavorites.add(productId);
      }
      return newFavorites;
    });
  };

  return (
    <div className="min-h-screen bg-background animate-fade-in">
      <Header cartItemsCount={cartItems.length} />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="gradient-hero">
          <div className="container mx-auto px-4 py-24 md:py-32">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6 animate-scale-in">
                <h1 className="text-4xl md:text-6xl font-bold text-primary-foreground leading-tight">
                  Shop at the 
                  <span className="block gradient-accent bg-clip-text text-transparent">
                    Speed of Swift
                  </span>
                </h1>
                <p className="text-lg md:text-xl text-primary-foreground/80 max-w-lg">
                  Experience lightning-fast delivery, unbeatable prices, and premium quality products. Your one-stop shop for everything you need.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link to="/products">
                    <Button size="lg" variant="secondary" className="w-full sm:w-auto hover-scale transition-swift">
                      Shop Now
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                  <Button size="lg" variant="outline" className="w-full sm:w-auto bg-white/10 text-primary-foreground border-white/20 hover:bg-white/20 hover-scale transition-swift">
                    Learn More
                  </Button>
                </div>
              </div>
              <div className="relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
                <img
                  src={heroImage}
                  alt="Swift Cart Hero"
                  className="w-full h-auto rounded-2xl shadow-strong hover-scale transition-swift"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Why Choose Swift Cart?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We're committed to providing the best shopping experience with unmatched speed and quality.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center space-y-4 animate-fade-in hover-scale transition-swift" style={{ animationDelay: '0.1s' }}>
              <div className="gradient-primary w-16 h-16 rounded-2xl flex items-center justify-center mx-auto">
                <Zap className="h-8 w-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold">Lightning Fast</h3>
              <p className="text-muted-foreground">
                Same-day delivery available in most areas. Get your products when you need them.
              </p>
            </div>
            
            <div className="text-center space-y-4 animate-fade-in hover-scale transition-swift" style={{ animationDelay: '0.2s' }}>
              <div className="gradient-accent w-16 h-16 rounded-2xl flex items-center justify-center mx-auto">
                <Shield className="h-8 w-8 text-accent-foreground" />
              </div>
              <h3 className="text-xl font-semibold">Secure & Safe</h3>
              <p className="text-muted-foreground">
                Your data and payments are protected with industry-leading security measures.
              </p>
            </div>
            
            <div className="text-center space-y-4 animate-fade-in hover-scale transition-swift" style={{ animationDelay: '0.3s' }}>
              <div className="gradient-primary w-16 h-16 rounded-2xl flex items-center justify-center mx-auto">
                <Truck className="h-8 w-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold">Free Shipping</h3>
              <p className="text-muted-foreground">
                Free shipping on all orders over $50. No hidden fees, no surprises.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div className="space-y-2">
              <h2 className="text-3xl md:text-4xl font-bold">Featured Products</h2>
              <p className="text-muted-foreground">Handpicked items just for you</p>
            </div>
            <Link to="/products">
              <Button variant="outline" className="hover-scale transition-swift">
                View All
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
                onToggleFavorite={handleToggleFavorite}
                isFavorite={favorites.has(product.id)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex justify-center mb-6">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-8 w-8 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            <h2 className="text-3xl md:text-4xl font-bold">
              Join thousands of happy customers
            </h2>
            <p className="text-lg text-muted-foreground">
              Over 50,000 customers trust Swift Cart for their shopping needs. 
              Experience the difference today!
            </p>
            <Link to="/products">
              <Button size="lg" className="gradient-primary text-primary-foreground hover-scale transition-swift">
                Start Shopping
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}